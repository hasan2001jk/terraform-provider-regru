# terraform-provider-regru
Terraform provider for reg.ru cloud servers.
